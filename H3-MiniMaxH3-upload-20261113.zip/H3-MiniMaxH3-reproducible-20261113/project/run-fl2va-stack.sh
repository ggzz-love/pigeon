#!/usr/bin/env bash
set -e
exec "$IFAB_AFS_HOME/h3/envs/py311-20261105-v1/bin/python" -u - <<'H3_CLANG_RUN'
import pathlib,hashlib,subprocess,sys,tempfile,zipfile
p=pathlib.Path('h3_gcc_pair_fl2va_v8_20261107.zip')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='9a67deaa1b6072c0bc7b2c23db192454178bd0b1b5454781ebb6cb96ac4a21eb'
d=pathlib.Path(tempfile.mkdtemp(prefix='h3-baseline-clang-'))
zipfile.ZipFile(p).extractall(d)
raise SystemExit(subprocess.call(['bash',str(d/'launch_crash_diagnosis.sh')]))
H3_CLANG_RUN
