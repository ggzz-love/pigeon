import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

archive = Path(__file__).resolve().parent / 'h3_condition_prefix_20261107.zip'
expected = '527d0d5fa5bc18a677814a367fab0c23802432c3f73faacaa3855ed25fd41857'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
root = Path(tempfile.mkdtemp(prefix='h3-aligned-probe-'))
allowed = {'condition_layers.py', 'launch_crash_diagnosis.py', 'trace_first_step.py',
           'launch_crash_diagnosis.sh', 'mha_nine_plugin.cpp', 'h3_crash_trace.c',
           'mha_startup/sitecustomize.py'}
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == allowed
    z.extractall(root)

def replace_once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new, 1)

p = root / 'condition_layers.py'
s = p.read_text(encoding='utf-8')
s = replace_once(s, '    intermediate = {}\n', '    intermediate = {}\n    aligned_states = {}\n')
s = replace_once(s, "        indices = [0, 1, 2, 3, 4, 8, 16, 32, 50]\n        states = {index: cpu_value(output.hidden_states[index]) for index in indices}\n", "        indices = [0, 1, 3, 8]\n        assert set(aligned_states) == set(indices), list(aligned_states)\n        states = aligned_states\n")
s = replace_once(s, '        encoder.model.language_model.register_forward_pre_hook(language_inputs, with_kwargs=True)\n', '''        encoder.model.language_model.register_forward_pre_hook(language_inputs, with_kwargs=True)
        def capture_input(depth):
            def hook(_module, args, kwargs):
                value = args[0] if args else kwargs['hidden_states']
                aligned_states[depth] = cpu_value(value.clone())
            return hook
        for depth in (0, 1, 3, 8):
            encoder.model.language_model.layers[depth].register_forward_pre_hook(capture_input(depth), with_kwargs=True)
''')
s = s.replace('compare(', 'aligned_compare(')
marker = 'def reference_pass(args):\n'
metrics = '''def aligned_compare(left, right, name, result):
    item = {'reference_shape': list(left.shape), 'native_shape': list(right.shape),
            'reference_dtype': str(left.dtype), 'native_dtype': str(right.dtype)}
    if left.shape != right.shape or not left.numel():
        result[name] = item
        return
    a, b = left.double().flatten(), right.double().flatten()
    item['reference_nonfinite'] = int((~torch.isfinite(a)).sum())
    item['native_nonfinite'] = int((~torch.isfinite(b)).sum())
    item['exact'] = torch.equal(left, right)
    if not item['reference_nonfinite'] and not item['native_nonfinite']:
        delta = a - b
        norm_a, norm_b = torch.linalg.vector_norm(a), torch.linalg.vector_norm(b)
        item.update(mean_abs=float(delta.abs().mean()), max_abs=float(delta.abs().max()),
                    relative_l2=float(torch.linalg.vector_norm(delta) / norm_a.clamp_min(1e-12)),
                    cosine=float(torch.dot(a, b) / (norm_a * norm_b).clamp_min(1e-12)))
    result[name] = item


'''
s = replace_once(s, marker, metrics + marker)
p.write_text(s, encoding='utf-8')
p = root / 'launch_crash_diagnosis.py'
s = p.read_text(encoding='utf-8')
s = replace_once(s, "run=afs/'h3/runs'/('h3-condition-prefix-'+time.strftime('%Y%m%d-%H%M%S'))\nrun.mkdir(parents=True,exist_ok=False)", "run=pathlib.Path(tempfile.mkdtemp(prefix='h3-condition-aligned-results-'))")
p.write_text(s, encoding='utf-8')
compile((root / 'condition_layers.py').read_text(encoding='utf-8'), str(root / 'condition_layers.py'), 'exec')
compile((root / 'launch_crash_diagnosis.py').read_text(encoding='utf-8'), str(root / 'launch_crash_diagnosis.py'), 'exec')
subprocess.run(['bash', '-n', str(root / 'launch_crash_diagnosis.sh')], check=True)
print('ALIGNED_PROBE_ROOT', root, flush=True)
if '--preflight' in sys.argv:
    print('ALIGNED_PREFLIGHT_OK', flush=True)
    raise SystemExit(0)
raise SystemExit(subprocess.call(['bash', str(root / 'launch_crash_diagnosis.sh')]))
