#!/usr/bin/env bash
set -e
exec "$IFAB_AFS_HOME/h3/envs/py311-20261105-v1/bin/python" -u - <<'H3_PROBE'
import os,pathlib,hashlib,zipfile,subprocess,sys
p=pathlib.Path(os.environ['IFAB_AFS_HOME'])/'h3_baseline_probe_v2_20261107.zip'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='69d25ae09d5d1505b714679c199e0f0cb1057fd9f7ea4692906a7754dcf71ba9'
out=pathlib.Path.cwd()/'baseline-probe-v2'
zipfile.ZipFile(p).extractall(out)
sys.exit(subprocess.call(['bash',str(out/'launch_baseline.sh')]))
H3_PROBE
