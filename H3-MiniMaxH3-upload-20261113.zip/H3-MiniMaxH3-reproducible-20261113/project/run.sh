#!/usr/bin/env bash
set -e
python - <<'H3_LOCAL_PREP'
import os,pathlib,tarfile,hashlib,json
base=pathlib.Path(os.environ['IFAB_AFS_HOME'])
archive=base/'h3_sources_20261106.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='085caa237533e7a1b8cab55499ad3d596ba347db1efb7d1b2e4ba8bcfc9d5c81'
out=pathlib.Path.cwd()/'local-source'
n=0
with tarfile.open(archive,'r:gz') as tf:
 for m in tf:
  parts=pathlib.PurePosixPath(m.name).parts
  assert '..' not in parts and not m.name.startswith('/')
  match=next((i for i,v in enumerate(parts) if v in ['InfiniCore','InfiniLM']),None)
  if match is None or not m.isfile() or '.git' in parts: continue
  p=out.joinpath(*parts[match:]); p.parent.mkdir(parents=True,exist_ok=True)
  data=tf.extractfile(m).read()
  if not p.exists() or p.read_bytes()!=data: p.write_bytes(data)
  n+=1
for repo in ['InfiniCore','InfiniLM']:
 p=base/'h3/runs/cpu-py-src-cc180812'/repo/'xmake.lua'
 target=out/repo/'xmake.lua'; data=p.read_bytes()
 if not target.exists() or target.read_bytes()!=data: target.write_bytes(data)
assert n>1000,n
(out/'LOCAL_PREP_OK.json').write_text(json.dumps({'files_written':n,'archive_sha256':'085caa237533e7a1b8cab55499ad3d596ba347db1efb7d1b2e4ba8bcfc9d5c81'}))
print('LOCAL_SOURCE_PREPARED',out,n,flush=True)
H3_LOCAL_PREP
python - <<'H3_PREP_SOURCE'
import os,pathlib,json
out=pathlib.Path(os.environ['IFAB_AFS_HOME'])/'h3/runs/cpu-py-src-cc180812'
meta=json.loads((out/'PREP_OK.json').read_text())
assert meta['archive_sha256']=='085caa237533e7a1b8cab55499ad3d596ba347db1efb7d1b2e4ba8bcfc9d5c81'
for f in ['InfiniCore/xmake.lua','InfiniLM/xmake.lua','InfiniCore/third_party/spdlog/include/spdlog/spdlog.h','InfiniLM/third_party/json/single_include/nlohmann/json.hpp']:
 assert (out/f).is_file(),f
print('CPU_SOURCE_REUSED',out,meta,flush=True)
H3_PREP_SOURCE
exec "$IFAB_AFS_HOME/h3/envs/py311-20261105-v1/bin/python" -u - <<'H3_LIVE_RUNNER'
import os,pathlib,subprocess,sys,time,json
root=pathlib.Path(os.environ["IFAB_AFS_HOME"])/"h3/runs"
run=root/("framework-live-"+time.strftime("%Y%m%d-%H%M%S"))
run.mkdir(parents=True,exist_ok=False)
os.environ["H3_BUILD_RUN"]=str(run)
local=pathlib.Path.cwd()/"xmake-local-state"
local.mkdir(exist_ok=True)
os.environ["H3_LOCAL_BUILD"]=str(local)
os.environ["H3_LOCAL_SOURCE"]=str(pathlib.Path.cwd()/"local-source")
script=r'''
#!/usr/bin/env bash
source /opt/dtk/env.sh
set -euo pipefail
H="$IFAB_AFS_HOME/h3"
source "$H/envs/py311-20261105-v1/bin/activate"
R="$H3_BUILD_RUN"
mkdir -p "$R"
exec 9>"$H/framework-build.lock"
flock -n 9
export PATH="$H/tools/xmake-3.0.5-20261106-103514-1882467/bin:/opt/dtk/llvm/bin:$PATH"
export XMAKE_GLOBALDIR="$H3_LOCAL_BUILD/global"
mkdir -p "$XMAKE_GLOBALDIR"
export XMAKE_PKG_CACHEDIR="$H3_LOCAL_BUILD/cache"
export XMAKE_PKG_INSTALLDIR="$H3_LOCAL_BUILD/packages"
mkdir -p "$XMAKE_PKG_CACHEDIR"
export PYTHON="$VIRTUAL_ENV/bin/python"
export PYTHONNOUSERSITE=1
export PYTHONPATH="$H/runs/cpu-py-src-cc180812/InfiniCore/python:$H/runs/cpu-py-src-cc180812/InfiniLM/python"
export HYGON_ARCH=gfx936
export INFINI_ROOT="$R/install"
export GIT_CONFIG_NOSYSTEM=1
export CC=/opt/dtk/llvm/bin/clang
export CXX=/opt/dtk/llvm/bin/clang++
export FA_SO_PATH="$VIRTUAL_ENV/lib/python3.11/site-packages/flash_attn_2_cuda.cpython-311-x86_64-linux-gnu.so"
export LD_LIBRARY_PATH="$INFINI_ROOT/lib:/opt/dtk/lib:/opt/dtk/cuda/cuda/lib64:/usr/local/lib/python3.11/site-packages/torch/lib:/opt/hyhal/lib:${LD_LIBRARY_PATH:-}"
export INFINILM_CXX11_ABI="$(python -c 'import torch; print(int(torch._C._GLIBCXX_USE_CXX11_ABI))')"
python -m pip list --format=json > "$R/dependencies.json"
python - <<'PY'
import os,pathlib
h=pathlib.Path(os.environ['IFAB_AFS_HOME'])
candidates=[h/'xmake-repo/xmake-repo-master',h/'xmake-repo',h/'h3/xmake-repo',h/'.xmake/repositories/xmake-repo']
for p in candidates:
 print('REPO_CHECK',p,{n:(p/'packages'/n[0]/n/'xmake.lua').is_file() for n in ['boost','openmp','pybind11']})
for p in candidates:
 if all((p/'packages'/n[0]/n/'xmake.lua').is_file() for n in ['boost','openmp','pybind11']):
  (h/'h3/cache/xmake-local-repo.txt').write_text(str(p))
  break
else:
 raise SystemExit('NO_COMPLETE_LOCAL_XMAKE_REPOSITORY')
PY
xmake repo -g -a h3-local "$(cat "$H/cache/xmake-local-repo.txt")"
export H3_PYBIND_INCLUDE="$H3_LOCAL_SOURCE/deps/pybind11-2.13.6/include"
export H3_PYTHON_INCLUDE="$(python -c 'import sysconfig; print(sysconfig.get_path("include"))')"
python - <<'H3_PATCHPY'
import os,pathlib,hashlib,difflib,zipfile
h=pathlib.Path(os.environ['IFAB_AFS_HOME'])/'h3'
r=pathlib.Path(os.environ['H3_BUILD_RUN'])
archive=h.parent/'pybind11-v2.13.6.zip'
raw=archive.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d0a116e91f64a4a2d8fb7590c34242df92258a61ec644b79127951e821b47be6'
dep=pathlib.Path(os.environ['H3_LOCAL_SOURCE'])/'deps/pybind11-2.13.6'
n=0
with zipfile.ZipFile(archive) as z:
 for member in z.infolist():
  parts=pathlib.PurePosixPath(member.filename).parts
  assert '..' not in parts and not member.filename.startswith('/')
  if len(parts)<2 or parts[1]!='include': continue
  p=dep.joinpath(*parts[1:])
  if member.is_dir(): p.mkdir(parents=True,exist_ok=True)
  else:
   p.parent.mkdir(parents=True,exist_ok=True)
   data=z.read(member)
   if not p.exists() or p.read_bytes()!=data: p.write_bytes(data)
   n+=1
assert (dep/'include/pybind11/pybind11.h').is_file()
for repo in ['InfiniCore','InfiniLM']:
 p=pathlib.Path(os.environ['H3_LOCAL_SOURCE'])/repo/'xmake.lua'
 old=p.read_text()
 (r/(repo+'.xmake.before-direct-headers.lua')).write_text(old)
 new=old.replace('add_requires("pybind11 2.13.6")','-- H3: pybind11 2.13.6 provided by verified offline headers.')
 new=new.replace('add_requires("pybind11")','-- H3: pybind11 2.13.6 provided by verified offline headers.')
 new=new.replace('add_packages("pybind11")','-- H3: offline pybind11 include paths are declared globally.')
 assert 'add_requires("pybind11' not in new
 marker='-- H3_OFFLINE_PYBIND_INCLUDE'
 if marker not in new:
  new=marker+'\nadd_includedirs(os.getenv("H3_PYBIND_INCLUDE"), os.getenv("H3_PYTHON_INCLUDE"))\n'+new
 if new!=old: p.write_text(new)
 (r/(repo+'.direct-headers.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=repo+'/xmake.lua.before',tofile=repo+'/xmake.lua')))
 print('DIRECT_HEADERS_READY',repo,n,os.environ['H3_PYBIND_INCLUDE'],flush=True)
H3_PATCHPY
xmake global --network=private
printf 'STAGE=configure_core\n'
cd "$H3_LOCAL_SOURCE/InfiniCore"
timeout 600 xmake f -vD -y --ccache=n --hygon-dcu=y --hygon-arch=gfx936 --cuda=/opt/dtk/cuda/cuda --ccl=y --aten=y --omp=n -m release
printf 'STAGE=build_core\n'
xmake build -j 8
xmake install
xmake build -j 8 _infinicore
xmake install _infinicore
python - <<'H3_PERSIST_NATIVE'
import os,pathlib
src=pathlib.Path.cwd(); target=pathlib.Path(os.environ['IFAB_AFS_HOME'])/'h3/runs/cpu-py-src-cc180812'/src.name
files=[]
for p in (src/'python').rglob('*.so*'):
 if p.is_file():
  dest=target/p.relative_to(src); dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(p.read_bytes()); files.append(str(dest))
assert any('_infinicore' in f or '_infinilm' in f for f in files),files
print('PERSIST_PYTHON_NATIVE',files,flush=True)
H3_PERSIST_NATIVE
printf 'STAGE=configure_lm\n'
cd "$H3_LOCAL_SOURCE/InfiniLM"
timeout 300 xmake f -y --ccache=n -m release
xmake build -j 8 _infinilm
xmake install _infinilm
python - <<'H3_PERSIST_NATIVE'
import os,pathlib
src=pathlib.Path.cwd(); target=pathlib.Path(os.environ['IFAB_AFS_HOME'])/'h3/runs/cpu-py-src-cc180812'/src.name
files=[]
for p in (src/'python').rglob('*.so*'):
 if p.is_file():
  dest=target/p.relative_to(src); dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(p.read_bytes()); files.append(str(dest))
assert any('_infinicore' in f or '_infinilm' in f for f in files),files
print('PERSIST_PYTHON_NATIVE',files,flush=True)
H3_PERSIST_NATIVE
python -c 'import infinicore,infinilm; print("FRAMEWORK_IMPORT_OK_NOT_VIDEO_OR_NINE_SUCCESS")'

'''
(run/"run.sh").write_text(script)
print("BUILD_LOG="+str(run/"build.log"),flush=True)
started=time.time()
with (run/"build.log").open("w",encoding="utf-8") as log:
    child=subprocess.Popen(["bash","-c",script],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding="utf-8",errors="replace",bufsize=1)
    for line in child.stdout:
        log.write(line)
        log.flush()
        print(line,end="",flush=True)
    code=child.wait()
(run/"exit_code").write_text(str(code))
(run/"status.json").write_text(json.dumps({"exit_code":code,"started":started,"ended":time.time()}))
print("FRAMEWORK_BUILD_EXIT="+str(code),flush=True)
sys.exit(code)
H3_LIVE_RUNNER
