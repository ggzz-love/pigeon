"""Archive exact installed package bytes for fast node-local imports."""
import hashlib
import importlib.metadata as metadata
import importlib.util
import io
import json
import os
from pathlib import Path
import tarfile
import time

afs=Path(os.environ['IFAB_AFS_HOME'])
root=afs/'h3'
run=root/'cache'/('python-runtime-'+time.strftime('%Y%m%d-%H%M%S'))
run.mkdir(parents=True,exist_ok=False)
archive=run/'packages.tar.gz'
manifest={'started':time.time(),'packages':{},'files':{},'complete':False}
count=0
total=0
seen=set()
print('PYTHON_CACHE_RUN='+str(run),flush=True)

def put_file(tf,path,name):
 global count,total
 if name in seen: return
 data=path.read_bytes()
 info=tarfile.TarInfo(name)
 info.size=len(data); info.mode=0o644; info.mtime=0
 tf.addfile(info,io.BytesIO(data))
 manifest['files'][name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 seen.add(name); count+=1; total+=len(data)
 if count%100==0:
  print('PYTHON_CACHE_PROGRESS',count,total,name,flush=True)

packages=['transformers','diffusers','huggingface_hub','httpcore','httpx','accelerate']
with tarfile.open(archive,'w:gz',compresslevel=1) as tf:
 for name in packages+['infinicore','infinilm']:
  if name in ['infinicore','infinilm']:
   repo='InfiniCore' if name=='infinicore' else 'InfiniLM'
   package=root/'runs/cpu-py-src-cc180812'/repo/'python'/name
   version='source checkout'
   distribution=None
  else:
   spec=importlib.util.find_spec(name)
   assert spec and spec.origin,name
   package=Path(spec.origin).parent
   distribution=metadata.distribution(name.replace('_','-'))
   version=distribution.version
  assert package.is_dir(),package
  manifest['packages'][name]={'version':version,'source':str(package)}
  print('PYTHON_CACHE_PACKAGE',name,version,package,flush=True)
  recorded=[]
  if distribution is not None:
   for entry in distribution.files or []:
    parts=Path(str(entry)).parts
    if parts and parts[0]==name and not any(p=='__pycache__' for p in parts) and not str(entry).endswith(('.pyc','.pyo')):
     recorded.append((Path(entry.locate()),str(entry).replace(os.sep,'/')))
   # Preserve distribution metadata so version checks resolve the same package.
   for entry in distribution.files or []:
    parts=Path(str(entry)).parts
    if parts and parts[0].endswith('.dist-info') and '..' not in parts:
     put_file(tf,Path(entry.locate()),str(entry).replace(os.sep,'/'))
  if recorded:
   for path,target in recorded: put_file(tf,path,target)
  else:
   for current,dirs,files in os.walk(package,followlinks=False):
    dirs[:]=[d for d in dirs if d not in ['__pycache__','.git']]
    for filename in files:
     if filename.endswith(('.pyc','.pyo')): continue
     path=Path(current)/filename
     put_file(tf,path,name+'/'+path.relative_to(package).as_posix())
manifest.update(complete=True,files_written=count,source_bytes=total,ended=time.time(),
                archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                archive_bytes=archive.stat().st_size)
(run/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
pointer={key:manifest[key] for key in ['archive','archive_sha256','archive_bytes','files_written','source_bytes','packages','complete']}
pointer['manifest']=str(run/'manifest.json')
(root/'cache/python-runtime-latest.json').write_text(json.dumps(pointer,indent=2),encoding='utf-8')
print('PYTHON_CACHE_COMPLETE',json.dumps(pointer),flush=True)
