#!/usr/bin/env bash
set -e
exec "$IFAB_AFS_HOME/h3/envs/py311-20261105-v1/bin/python" -u - <<'H3_FL2VA'
import pathlib,hashlib,zipfile,subprocess,sys
p=pathlib.Path.cwd()/'h3_baseline_local_v3_20261107.zip'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='00b67f0453289c5a1c5d6cfed8db78beb607c9c0856a7c0dc2a5ffb3e2cf74b2'
out=pathlib.Path.cwd()/'fl2va-launch'
zipfile.ZipFile(p).extractall(out)
sys.exit(subprocess.call(['bash',str(out/'launch_baseline.sh')]))
H3_FL2VA
