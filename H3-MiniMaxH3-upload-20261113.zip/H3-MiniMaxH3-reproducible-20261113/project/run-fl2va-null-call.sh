#!/usr/bin/env bash
set -e
exec "$IFAB_AFS_HOME/h3/envs/py311-20261105-v1/bin/python" -u - <<'H3_CLANG_RUN'
import pathlib,hashlib,subprocess,sys,tempfile,zipfile
p=pathlib.Path('h3_gcc_pair_fl2va_v7_20261107.zip')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='450c2069ba248e5e88df5a9674550ef042089367df0fc56867b209c70fc96a41'
d=pathlib.Path(tempfile.mkdtemp(prefix='h3-baseline-clang-'))
zipfile.ZipFile(p).extractall(d)
raise SystemExit(subprocess.call(['bash',str(d/'launch_crash_diagnosis.sh')]))
H3_CLANG_RUN
