#!/usr/bin/env bash
source /opt/dtk/env.sh
set -euo pipefail
source "$IFAB_AFS_HOME/h3/envs/py311-20261105-v1/bin/activate"
export PYTHONNOUSERSITE=1
export PATH="/opt/dtk/cuda/cuda/bin:/opt/dtk/llvm/bin:$PATH"
export LD_LIBRARY_PATH="/opt/dtk/lib:/opt/dtk/cuda/cuda/lib64:/usr/local/lib/python3.11/site-packages/torch/lib:/opt/hyhal/lib:${LD_LIBRARY_PATH:-}"
export H3_NINE_ORIGINAL_AOT_SHA256=7028755b034befd3f3a9c00d02931cc555f50730d0594de572b3edcd629494ca
exec python -u - <<'H3_AOT'
import hashlib,pathlib,subprocess,sys,tempfile,zipfile
p=pathlib.Path('h3_nine_mha_differential_20261107.zip')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='0c210a6aa61cb9c59c5ce4b4570e97f34726cb6a93d97ca51e301c5e29eb9274'
d=pathlib.Path(tempfile.mkdtemp(prefix='h3-aot-launch-'))
with zipfile.ZipFile(p) as z: z.extractall(d)
raise SystemExit(subprocess.call([sys.executable,'-u',str(d/'validate_backend.py')]))
H3_AOT
