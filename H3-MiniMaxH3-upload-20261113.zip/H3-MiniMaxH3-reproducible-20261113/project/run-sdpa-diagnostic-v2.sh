#!/usr/bin/env bash
set -e
exec "$IFAB_AFS_HOME/h3/envs/py311-20261105-v1/bin/python" -u - <<'H3_CLANG_RUN'
import pathlib,hashlib,subprocess,sys,tempfile,zipfile
p=pathlib.Path('h3_sdpa_diagnostic_v2_20261107.zip')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='d9d3b4974d2fef8da693874e71e8d1e4210cf5eb478613afda06ddfe0d8951e0'
d=pathlib.Path(tempfile.mkdtemp(prefix='h3-baseline-clang-'))
zipfile.ZipFile(p).extractall(d)
raise SystemExit(subprocess.call(['bash',str(d/'launch_crash_diagnosis.sh')]))
H3_CLANG_RUN
