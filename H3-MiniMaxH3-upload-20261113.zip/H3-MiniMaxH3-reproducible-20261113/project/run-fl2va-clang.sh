#!/usr/bin/env bash
set -e
exec "$IFAB_AFS_HOME/h3/envs/py311-20261105-v1/bin/python" -u - <<'H3_CLANG_RUN'
import pathlib,hashlib,subprocess,sys,tempfile,zipfile
p=pathlib.Path('h3_baseline_clang_v4_20261107.zip')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='460c2e49b8be191c30c63c339dfd008f04f189f7161ad8c95fe2d110806c80d3'
d=pathlib.Path(tempfile.mkdtemp(prefix='h3-baseline-clang-'))
zipfile.ZipFile(p).extractall(d)
raise SystemExit(subprocess.call(['bash',str(d/'launch_baseline.sh')]))
H3_CLANG_RUN
