# MiniMax H3 FL2VA 可复现提交包

本包整合了参赛工程的完整源码快照、所有项目运行入口、v7 九齿 MHA 运行覆盖、依赖归档、统一输入图和已有运行证据。仓库入口为 `project/run-nine-mha-endtoend-v7.sh` 和 `project/run-fl2va-direct.sh`。

## 目录

- `archives/h3_sources_20261106.tar.gz`：完整固定版本源码归档；解压后得到 InfiniCore 与 InfiniLM 目录。
- `project/`：原项目全部运行/构建/诊断入口及各版本 ZIP；其中 `run-nine-mha-endtoend-v7.sh` 和 `run-fl2va-direct.sh` 是 v7 成功运行入口。
- `runtime/v7-nine/`、`runtime/v7-fl2va/`：v7 九齿注意力和 FL2VA 入口的解压代码，便于审查实际 Python/C++ 文件。
- `dependencies/`：本地已归档的 xmake、xmake-repo 和 pybind11 构建输入。
- `input/`：统一首帧输入图片。
- `evidence/`：已有八卡成功运行日志、媒体规格、九齿数值/调度结果和生成视频。
- `patches/`：候选补丁；文件名和 README 已明确哪些补丁未在成功作业中验证，不能误用。

## 赛事环境中的复现顺序

在组委会提供的 `scnet-dcu` 统一镜像、8 张 `gfx936` 卡和共享模型环境中执行：

```bash
export IFAB_AFS_HOME=/path/to/your/afs
cd project

# 完整源码构建入口。它会在 $IFAB_AFS_HOME/h3/runs 下建立隔离构建目录。
bash run.sh

# v7 九齿 MHA 的 AOT/JIT 和 8 卡真实调度验证。
bash run-nine-mha-endtoend-v7.sh

# 使用验证目录生成 FL2VA；把时间戳目录替换为本次验证输出。
NINE_RUN="$IFAB_AFS_HOME/h3/runs/nine-mha-e2e-YYYYMMDD-HHMMSS"
bash run-fl2va-direct.sh --verified-nine-run "$NINE_RUN"
```

原入口使用赛事账号中的 `$IFAB_AFS_HOME/h3` Python 环境、框架安装、运行时缓存和平台共享模型；这些属于统一算力环境或账号资源，不应上传到 GitHub。模型路径默认为 `/public/home/aclsylqidf/shared/MiniMax-H3`，也可按组委会环境调整 `--model-path`。

成功运行的固定参数为统一首帧、提示词 `A dog falls asleep`、seed 42、50 步、124 帧、8 卡 `0,1,2,3,4,5,6,7`。生成入口会校验九齿验证结果、内核哈希、设备覆盖和视频规格。

## 已有成功证据

- 生成退出码 0，设备 0--7 均有九齿 MHA 调用。
- 输出 768x928、124 帧、24 fps，H.264 视频，32 kHz 双声道 AAC。
- AOT/JIT 数值测试通过，真实 8 设备 40 次调度通过。
- 模型入口耗时 410.100 s；Transformer 49 次调用累计 323.701 s。

以上证据来自此前在统一赛事环境完成的运行，原始 JSON、日志和视频保存在 `evidence/`。官方 SSIM 比较应在评测环境中用官方 `InfiniLM/examples/minimax_h3_compare.py` 重新执行；交接记录中的 58.332% 和 70.553% 仅是历史记录，不能替代原始比较输出。

## 复现边界

本包不包含赛事基础镜像、Hygon 驱动、组委会共享模型权重和账号个人 AFS 缓存；这些由比赛平台统一提供。包内源码、构建入口和运行覆盖已完整归档，评审时应以组委会的统一环境执行上述流程。候选补丁不属于已验证 v7 结果，除非重新构建并完成 AOT/JIT、真实调度和官方 FL2VA 比较，不要应用它们。
