"""Compare two already generated videos using the unchanged official metric."""

import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()



def numpy_ssim(left, right, *, data_range):
    """Grayscale uint8 SSIM with the comparator's 7x7 sample window."""
    import numpy as np

    if left.dtype != np.uint8 or right.dtype != np.uint8 or left.ndim != 2:
        raise ValueError("expected grayscale uint8 images")
    if left.shape != right.shape or min(left.shape) < 7 or data_range != 255:
        raise ValueError("invalid image shape or data range")
    left = left.astype(np.int64)
    right = right.astype(np.int64)

    def mean7(array):
        padded = np.pad(array, ((1, 0), (1, 0)))
        integral = padded.cumsum(axis=0).cumsum(axis=1)
        sums = integral[7:, 7:] - integral[:-7, 7:] - integral[7:, :-7] + integral[:-7, :-7]
        return sums / 49.0

    ux, uy = mean7(left), mean7(right)
    cov = (49.0 / 48.0) * (mean7(left * right) - ux * uy)
    vx = (49.0 / 48.0) * (mean7(left * left) - ux * ux)
    vy = (49.0 / 48.0) * (mean7(right * right) - uy * uy)
    c1, c2 = (0.01 * data_range) ** 2, (0.03 * data_range) ** 2
    score = ((2 * ux * uy + c1) * (2 * cov + c2)) / ((ux ** 2 + uy ** 2 + c1) * (vx + vy + c2))
    return float(score.mean(dtype=np.float64))


def install_process_local_metric():
    # Keep the upstream decoding, preprocessing, and frame comparison intact.
    # The SSIM result records this independent implementation explicitly.
    metrics = types.ModuleType("skimage.metrics")
    metrics.structural_similarity = numpy_ssim
    sys.modules["skimage.metrics"] = metrics


def inspect_media(path):
    import av

    with av.open(str(path)) as media:
        audio = [
            {'codec': stream.codec_context.name, 'channels': stream.channels,
             'sample_rate': stream.sample_rate}
            for stream in media.streams.audio
        ]
        return {'path': str(path), 'sha256': sha256(path), 'bytes': path.stat().st_size,
                'video_codec': media.streams.video[0].codec_context.name, 'audio': audio}


def main():
    root = Path(os.environ['IFAB_AFS_HOME']) / 'h3' / 'runs'
    official = root / 'cpu-py-src-cc180812/InfiniLM/examples/minimax_h3_compare.py'
    official_digest = sha256(official)
    if official_digest != 'e143c28e4b3acb885662e0aa238aa00ca17cbcc82077f465f2ce57d0f1225590':
        raise ValueError(f'official comparator hash mismatch: {official_digest}')
    reference = root / 'baseline-preflight-20261106-234201/comparison/reference_fl2va.mp4'
    candidate_run = sys.argv[1] if len(sys.argv) == 2 else 'sdpa-diagnostic-20261107-092951'
    if Path(candidate_run).name != candidate_run or candidate_run in ('', '.', '..'):
        raise ValueError('expected the name of an existing run under h3/runs')
    diagnostic = root / candidate_run / 'comparison/infinilm_fl2va.mp4'
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S')
    result_path = root / f'{candidate_run}-compare-{stamp}' / 'comparison.json'
    result_path.parent.mkdir()
    print(f'CPU_COMPARE_START {result_path}', flush=True)
    install_process_local_metric()
    spec = importlib.util.spec_from_file_location('official_fl2va_compare', official)
    comparator = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = comparator
    spec.loader.exec_module(comparator)
    result = {
        'comparator_sha256': official_digest,
        'ssim_backend': 'Independent NumPy 7x7 sample-covariance implementation',
        'reference': inspect_media(reference),
        'candidate': inspect_media(diagnostic),
        'metrics': comparator.compare_video_streams(reference, diagnostic),
    }
    report = json.dumps(result, indent=2)
    result_path.write_text(report + '\n', encoding='utf-8')
    print(report, flush=True)
    print(f'CPU_COMPARE_DONE {result_path}', flush=True)


if __name__ == '__main__':
    main()
