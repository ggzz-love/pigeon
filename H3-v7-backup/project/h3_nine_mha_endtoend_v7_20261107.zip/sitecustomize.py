import os
if os.environ.get('H3_NINE_GEP_COMPAT')=='1':
    from h3_backend_compat import install
    install()
