"""Private, immutable cache files for a filesystem without atomic rename.

Uses Triton's supported TRITON_CACHE_MANAGER extension. Each process has a
separate namespace. Files become visible only after a completion marker is
written; completed contents never change. Vendor Triton files are untouched.
"""
from collections import defaultdict
import hashlib
import os
from pathlib import Path
import threading

from triton.runtime.cache import FileCacheManager

_locks = defaultdict(threading.RLock)


class PrivateProcessCache(FileCacheManager):
    def __init__(self, key, override=False, dump=False):
        super().__init__(key + '-pid-' + str(os.getpid()), override=override, dump=dump)

    def has_file(self, filename):
        path = Path(self._make_path(filename))
        return path.is_file() and Path(str(path) + '.h3-ready').is_file()

    def put(self, data, filename, binary=True):
        data = data if isinstance(data, bytes) else str(data).encode('utf-8')
        path = Path(self._make_path(filename))
        marker = Path(str(path) + '.h3-ready')
        with _locks[str(path)]:
            if marker.is_file():
                if path.read_bytes() != data:
                    raise RuntimeError('An immutable Triton cache entry changed: ' + str(path))
                return str(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('wb') as stream:
                stream.write(data)
                stream.flush()
            marker.write_text(hashlib.sha256(data).hexdigest())
        return str(path)
