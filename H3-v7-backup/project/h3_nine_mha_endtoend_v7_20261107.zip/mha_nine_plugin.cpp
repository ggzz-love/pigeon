#include "infinicore/ops/mha.hpp"
#include "infinicore/context/context.hpp"
#include <atomic>
#include <array>
#include <dlfcn.h>
#include <stdexcept>
#include <cstdio>
#include <climits>
#include <string>

namespace {
using infinicore::Tensor;
using NineStream = void*;
struct NineTensor {void *data; uint64_t *shape; int64_t *strides;};
using Launch = int (*)(NineStream,NineTensor,NineTensor,NineTensor,NineTensor,NineTensor,NineTensor,NineTensor,NineTensor,NineTensor,NineTensor);
struct View {
    Tensor tensor;
    std::array<uint64_t,4> shape{};
    std::array<int64_t,4> stride{};
    explicit View(Tensor t):tensor(t) {
        if (t->ndim()!=4) throw std::runtime_error("Nine MHA requires rank 4");
        for(size_t i=0;i<4;++i) {shape[i]=t->size(i);stride[i]=t->stride(i);}
        if(stride[3]!=1) throw std::runtime_error("Nine MHA expects contiguous embedding dimension");
    }
    NineTensor arg(){return {tensor->data(),shape.data(),stride.data()};}
};
struct Plan {
    Tensor source_out,source_q,source_k,source_v;
    View out,q,k,v;
    Tensor host_len,device_len;
    std::array<uint64_t,1> length_shape{};
    std::array<int64_t,1> length_stride{{1}};
    float scale;
    bool causal;
    Launch launch;
    static Tensor padded(Tensor tensor) {
        if (tensor->ndim()!=4 || !tensor->numel())
            throw std::runtime_error("Nine MHA requires nonempty BSHD tensors");
        if (tensor->size(3)==128) return tensor;
        if (tensor->size(3)!=72) throw std::runtime_error("Nine MHA supports head dimensions 72 and 128");
        auto shape=tensor->shape(); shape[3]=128;
        return Tensor::empty(shape,tensor->dtype(),tensor->device());
    }
    Plan(Tensor o,Tensor qq,Tensor kk,Tensor vv,float s,bool c):
        source_out(o),source_q(qq),source_k(kk),source_v(vv),
        out(padded(o)->permute({0,2,1,3})),q(padded(qq)->permute({0,2,1,3})),
        k(padded(kk)->permute({0,2,1,3})),v(padded(vv)->permute({0,2,1,3})),scale(s),causal(c) {
        if(q.tensor->dtype()!=infinicore::DataType::BF16 ||
           k.tensor->dtype()!=q.tensor->dtype() || v.tensor->dtype()!=q.tensor->dtype() ||
           out.tensor->dtype()!=q.tensor->dtype())
            throw std::runtime_error("Nine MHA currently supports BF16");
        if(q.shape[0]!=k.shape[0] || k.shape!=v.shape || out.shape!=q.shape ||
           q.shape[1]%k.shape[1]!=0 || q.shape[3]!=k.shape[3] || k.shape[2]>INT32_MAX ||
           qq->size(3)!=kk->size(3) || qq->size(3)!=vv->size(3) || qq->size(3)!=o->size(3))
            throw std::runtime_error("Invalid Nine MHA tensor dimensions");
        if(causal && q.shape[2]!=k.shape[2])
            throw std::runtime_error("Native MHA causal path requires equal query/key sequence lengths");
        length_shape[0]=q.shape[0];
        host_len=Tensor::empty({q.shape[0]},infinicore::DataType::I32,infinicore::Device::cpu());
        auto ptr=reinterpret_cast<int32_t*>(host_len->data());
        for(size_t i=0;i<q.shape[0];++i) ptr[i]=static_cast<int32_t>(k.shape[2]);
        device_len=host_len->to(qq->device());
        launch=reinterpret_cast<Launch>(dlsym(RTLD_DEFAULT,c?"launch_h3_nine_mha_bf16_c1":"launch_h3_nine_mha_bf16_c0"));
        if(!launch) throw std::runtime_error("Nine MHA AOT library is not loaded");
    }
};
std::atomic<uint64_t> launches{0};
std::atomic<uint64_t> devices_seen{0};
void *plan(Tensor out,const Tensor&q,const Tensor&k,const Tensor&v,
           std::optional<Tensor> alibi,float scale,bool causal) {
    if(alibi) throw std::runtime_error("Nine MHA ALiBi is unsupported");
    return new Plan(out,q,k,v,scale,causal);
}
void run(void *p) {
    auto &m=*reinterpret_cast<Plan*>(p);
    auto stream=infinicore::context::getStream();
    const auto original_head=m.source_q->size(3);
    if (original_head!=128) {
        auto stage=[&](View &target,const Tensor &input) {
            infinicore::context::setDeviceMemoryAsync(target.tensor->data(),0,target.tensor->nbytes(),stream);
            target.tensor->narrow({{3,0,original_head}})->copy_from(input->permute({0,2,1,3}));
        };
        stage(m.q,m.source_q); stage(m.k,m.source_k); stage(m.v,m.source_v);
    }
    NineTensor total{m.device_len->data(),m.length_shape.data(),m.length_stride.data()};
    NineTensor empty{nullptr,nullptr,nullptr},scale{&m.scale,nullptr,nullptr};
    // Even when the mask is compiled out, the generated dispatcher checks its
    // final stride before choosing the specialization.
    std::array<uint64_t,4> mask_shape{{1,1,1,128}};
    std::array<int64_t,4> mask_strides{{128,128,128,1}};
    NineTensor unused_mask{nullptr,mask_shape.data(),mask_strides.data()};
    // Causal mode and mask options are specialized in the Nine-generated entry.
    int code=m.launch(reinterpret_cast<void*>(stream),
        m.q.arg(),m.k.arg(),m.v.arg(),total,unused_mask,empty,scale,m.out.arg(),empty,empty);
    if(code) throw std::runtime_error("Nine MHA AOT launch failed: "+std::to_string(code));
    if(original_head!=128)
        m.source_out->permute({0,2,1,3})->copy_from(m.out.tensor->narrow({{3,0,original_head}}));
    auto n=++launches;
    auto device=m.q.tensor->device().getIndex();
    auto bit=uint64_t{1} << (device%64);
    if(!(devices_seen.fetch_or(bit)&bit)) std::fprintf(stderr,"H3_NINE_MHA_LAUNCH count=%llu device=%zu qseq=%llu kseq=%llu causal=%d\n",
        (unsigned long long)n,device,
        (unsigned long long)m.q.shape[2],(unsigned long long)m.k.shape[2],m.causal);
}
void cleanup(void **ptr){delete reinterpret_cast<Plan*>(*ptr);*ptr=nullptr;}
}
extern "C" int h3_mha_has_native_plan(){
 return infinicore::op::MultiheadAttention::plan_dispatcher().lookup(infinicore::Device::Type::HYGON)!=nullptr;
}
extern "C" int h3_register_nine_mha(){
 auto device=infinicore::Device::Type::HYGON;
 auto &pd=infinicore::op::MultiheadAttention::plan_dispatcher();
 if(pd.lookup(device)) return 1;
 pd.registerDevice(device,&plan);
 infinicore::op::MultiheadAttention::run_dispatcher().registerDevice(device,&run);
 infinicore::op::MultiheadAttention::cleanup_dispatcher().registerDevice(device,&cleanup);
 return 0;
}
extern "C" uint64_t h3_nine_mha_launch_count(){return launches.load();}
