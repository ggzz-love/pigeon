import hashlib,io,json,os,pathlib,subprocess,sys,tarfile,tempfile,time,threading

afs=pathlib.Path(os.environ['IFAB_AFS_HOME'])
source=afs/'h3/runs/cpu-py-src-cc180812'
run=afs/'h3/runs'/('baseline-preflight-'+time.strftime('%Y%m%d-%H%M%S'))
run.mkdir(parents=True,exist_ok=False)
cache=json.loads(pathlib.Path(os.environ['H3_RUNTIME_CACHE_POINTER']).read_text())
assert cache['complete'] is True
raw=pathlib.Path(cache['archive']).read_bytes()
assert hashlib.sha256(raw).hexdigest()==cache['archive_sha256']
manifest=json.loads(pathlib.Path(cache['manifest']).read_text())
local_runtime=pathlib.Path(tempfile.mkdtemp(prefix='h3-python-runtime-'))
local_runtime.mkdir(exist_ok=True)
count=0
print('RUNTIME_CACHE_EXTRACT_START',cache['files_written'],cache['packages'],flush=True)
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
 for member in tf:
  parts=pathlib.PurePosixPath(member.name).parts
  assert '..' not in parts and not member.name.startswith('/') and member.isfile()
  data=tf.extractfile(member).read()
  expected=manifest['files'][member.name]
  assert len(data)==expected['bytes']
  assert hashlib.sha256(data).hexdigest()==expected['sha256'],member.name
  target=local_runtime.joinpath(*parts); target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(data); count+=1
  if count%500==0: print('RUNTIME_CACHE_EXTRACT',count,flush=True)
assert count==cache['files_written']
print('RUNTIME_CACHE_VERIFIED',count,local_runtime,flush=True)
env=os.environ.copy()
env['H3_PYTHON_RUNTIME']=str(local_runtime)
env['PYTHONPATH']=os.pathsep.join(str(p) for p in [local_runtime,afs/'h3/deps/xxhash-3.6.0',source/'InfiniCore/python',source/'InfiniLM/python'])
status={'scope':'baseline framework and official FL2VA comparison; model Nine dispatch not yet adapted',
        'started':time.time(),'complete':False}
print('BASELINE_RUN_DIR='+str(run),flush=True)

def execute(name,args,timeout=None):
 with (run/(name+'.log')).open('w',encoding='utf-8') as log:
  p=subprocess.Popen(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                     text=True,encoding='utf-8',errors='replace',bufsize=1)
  timer=None
  def stop_overdue():
   print('STAGE_TIMEOUT '+name,flush=True)
   try: p.terminate()
   except ProcessLookupError: return
   def kill_overdue():
    if p.poll() is None:
     try: p.kill()
     except ProcessLookupError: pass
   killer=threading.Timer(10,kill_overdue); killer.daemon=True; killer.start()
  if timeout:
   timer=threading.Timer(timeout,stop_overdue); timer.daemon=True; timer.start()
  try:
   for line in p.stdout:
    print(line,end='',flush=True); log.write(line); log.flush()
   return p.wait()
  finally:
   if timer: timer.cancel()
   if p.poll() is None:
    p.terminate()
    try: p.wait(timeout=10)
    except subprocess.TimeoutExpired: p.kill(); p.wait()


# First prove the generated kernels and the InfiniCore bridge independently.
helpers=pathlib.Path(os.environ['H3_BASELINE_HELPERS'])
mha_run=afs/'h3/runs'/('nine-mha-e2e-'+time.strftime('%Y%m%d-%H%M%S'))
env['H3_NINE_MHA_VALIDATION_RUN']=str(mha_run)
code=execute('nine-mha-compile-and-validate',[sys.executable,'-u',str(helpers/'validate_backend.py')],1500)
if code: raise SystemExit(code)
mha_evidence=json.loads((mha_run/'result.json').read_text())
assert mha_evidence['passed'] is True
mha_artifacts=pathlib.Path(tempfile.mkdtemp(prefix='h3-mha-artifacts-'))
for causal in [0,1]:
 name=f'h3_nine_mha_bf16_c{causal}.so'
 data=(mha_run/'aot'/name).read_bytes()
 assert hashlib.sha256(data).hexdigest()==mha_evidence['modes']['aot']['result']['generated_files'][name]
 (mha_artifacts/name).write_bytes(data)
code=execute('nine-mha-native-dispatch',[sys.executable,'-u',str(helpers/'native_dispatch_selftest.py'),str(mha_artifacts),str(helpers)],240)
if code: raise SystemExit(code)
for name in ['h3_nine_mha_plugin.so','native-dispatch-result.json']:
 (mha_run/name).write_bytes((mha_artifacts/name).read_bytes())
env['H3_NINE_MHA_ARTIFACTS']=str(mha_artifacts)
env['H3_NINE_MHA_STARTUP']=str(helpers/'mha_startup')
status['nine_mha_validation']=str(mha_run)

output=run/'comparison'
helpers=pathlib.Path(os.environ['H3_BASELINE_HELPERS'])
command=[sys.executable,'-u',str(helpers/'h3_compare_run.py'),
 '--framework-prefix',os.environ['INFINI_ROOT'],'--source-root',str(source),
 '--output-dir',str(output),'--native-crash-trace',str(helpers/'h3_crash_trace.so'),
 '--reference-fl2va-video',os.environ['H3_REFERENCE_FL2VA_VIDEO']]
status['scope']='Nine MHA native dispatch diagnostic and official FL2VA comparison; VAE boundary not certified'
code=execute('official-comparison',command)
independent_code = None
if code != 0 and (output/'infinilm_fl2va.mp4').is_file():
 independent_code = execute('independent-cpu-comparison', [sys.executable, '-u',
     str(helpers/'compare_numpy.py'), run.name], 180)
status.update(comparison_exit_code=code, independent_comparison_exit_code=independent_code,
 comparison_output=str(output),complete=code==0,ended=time.time())
(run/'status.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
print(json.dumps(status,indent=2),flush=True)
raise SystemExit(code)
