"""Register an already numerically validated Nine AOT bridge in the official child."""
import os
if os.environ.get('H3_NINE_MHA_ARTIFACTS'):
    try:
        import ctypes, pathlib
        import torch
        import infinicore
        p=pathlib.Path(os.environ['H3_NINE_MHA_ARTIFACTS'])
        kernels=[ctypes.CDLL(str(p/f'h3_nine_mha_bf16_c{c}.so'),mode=ctypes.RTLD_GLOBAL) for c in (0,1)]
        bridge=ctypes.CDLL(str(p/'h3_nine_mha_plugin.so'),mode=ctypes.RTLD_GLOBAL)
        assert bridge.h3_mha_has_native_plan()==0
        assert bridge.h3_register_nine_mha()==0 and bridge.h3_mha_has_native_plan()==1
        print('H3_NATIVE_NINE_MHA_REGISTERED',flush=True)
    except BaseException:
        import traceback
        traceback.print_exc()
        os._exit(78)
