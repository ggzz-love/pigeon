#define _GNU_SOURCE
#include <execinfo.h>
#include <dlfcn.h>
#include <stdint.h>
#include <signal.h>
#include <string.h>
#include <ucontext.h>
#include <sys/uio.h>
#include <unistd.h>

static void emit(const char *s, size_t n) {
    const ssize_t ignored = write(STDERR_FILENO, s, n);
    (void)ignored;
}

static void emit_address(const char *label, uintptr_t v) {
    const char digits[] = "0123456789abcdef";
    char out[2 + 2 * sizeof(v) + 1] = {'0', 'x'};
    for (size_t i = 0; i < 2 * sizeof(v); ++i) {
        out[2 + 2 * sizeof(v) - 1 - i] = digits[v & 15];
        v >>= 4;
    }
    out[sizeof(out) - 1] = '\n';
    emit(label, strlen(label));
    emit(out, sizeof(out));
}

static void emit_symbol(uintptr_t address) {
    Dl_info info;
    if (!address || !dladdr((void *)address, &info)) return;
    if (info.dli_fname) {
        emit(info.dli_fname, strlen(info.dli_fname));
        emit_address("+", address - (uintptr_t)info.dli_fbase);
    }
    if (info.dli_sname) {
        emit(info.dli_sname, strlen(info.dli_sname));
        emit_address("+", address - (uintptr_t)info.dli_saddr);
    }
}

// Optional host-side diagnostic; no model operations or device code.
static void report_segv(int signum, siginfo_t *info, void *context) {
    static const char marker[] = "\nH3_NATIVE_SEGFAULT_BACKTRACE\n";
    emit(marker, sizeof(marker) - 1);
    if (info && info->si_code > 0) emit_address("fault_address=", (uintptr_t)info->si_addr);
#if defined(__x86_64__) && defined(REG_RIP)
    if (context) {
        const ucontext_t *uc = (const ucontext_t *)context;
        const uintptr_t ip = (uintptr_t)uc->uc_mcontext.gregs[REG_RIP];
        emit_address("instruction_pointer=", ip);
        emit_symbol(ip);
        if (ip == 0) {
            const uintptr_t sp = (uintptr_t)uc->uc_mcontext.gregs[REG_RSP];
            uintptr_t words[32] = {0};
            struct iovec dst = {words, sizeof(words)};
            struct iovec src = {(void *)sp, sizeof(words)};
            ssize_t n = process_vm_readv(getpid(), &dst, 1, &src, 1, 0);
            emit_address("stack_pointer=", sp);
            uintptr_t here = (uintptr_t)&words[0];
            if (n < (ssize_t)sizeof(uintptr_t) && sp > here && sp - here < 32768 &&
                sp % sizeof(uintptr_t) == 0) {
                // The kernel delivered this handler on the interrupted thread's
                // own stack. Read only the saved return word in that mapping.
                words[0] = *(volatile const uintptr_t *)sp;
                n = sizeof(uintptr_t);
            }
            if (n >= (ssize_t)sizeof(uintptr_t)) {
                emit_address("null_call_return_address=", words[0]);
                emit_symbol(words[0]);
                if (words[0]) {
                    unsigned char instruction[16];
                    struct iovec code = {instruction, sizeof(instruction)};
                    struct iovec pc = {(void *)(words[0] - sizeof(instruction)), sizeof(instruction)};
                    if (process_vm_readv(getpid(), &code, 1, &pc, 1, 0) == sizeof(instruction)) {
                        for (size_t i = 0; i < sizeof(instruction); ++i)
                            emit_address("preceding_code_byte=", instruction[i]);
                    }
                }
                for (size_t i = 1; i < (size_t)n / sizeof(uintptr_t); ++i)
                    emit_symbol(words[i]);
            }
        }
    }
#endif
    void *frames[80];
    int count = backtrace(frames, sizeof(frames) / sizeof(frames[0]));
    backtrace_symbols_fd(frames, count, STDERR_FILENO);
    struct sigaction reset;
    memset(&reset, 0, sizeof(reset));
    reset.sa_handler = SIG_DFL;
    sigemptyset(&reset.sa_mask);
    sigaction(signum, &reset, 0);
    raise(signum);
}

__attribute__((constructor)) static void initialize_trace(void) {
    void *warm[2];
    (void)backtrace(warm, 2);
    struct sigaction action;
    memset(&action, 0, sizeof(action));
    action.sa_sigaction = report_segv;
    sigemptyset(&action.sa_mask);
    action.sa_flags = SA_SIGINFO;
    sigaction(SIGSEGV, &action, 0);
}
