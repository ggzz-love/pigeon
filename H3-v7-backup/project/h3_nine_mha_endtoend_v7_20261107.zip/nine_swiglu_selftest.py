"""Test upstream Nine flash attention on Hygon; numerical oracle is test-only."""
import argparse, ctypes, hashlib, json, pathlib, time, traceback
import torch, ninetoothed as nt
import flash_attention as fa

p=argparse.ArgumentParser()
p.add_argument('--mode',choices=['aot','jit'],required=True)
p.add_argument('--output-dir',type=pathlib.Path,required=True)
args=p.parse_args(); args.output_dir.mkdir(exist_ok=True,parents=True)
report={'scope':'standalone upstream Nine flash attention; no model claim','passed':False,'mode':args.mode,'cases':[]}
try:
 torch.cuda.set_device(0); torch.manual_seed(42)
 for causal in [0,1]:
  arrangement,application,tensors=fa.premake(with_kv_cache=0,emb_dim=128,is_causal=causal,with_attn_mask=0,causal_variant=fa.CausalVariant.LOWER_RIGHT,dtype=nt.bfloat16,block_size_m=64,block_size_n=64)
  name='h3_nine_mha_bf16_c'+str(causal)
  opts=dict(caller='cuda' if args.mode=='aot' else 'torch',kernel_name=name,num_warps=4,num_stages=1)
  if args.mode=='aot': opts['output_dir']=args.output_dir
  kernel=nt.make(arrangement,application,tensors,**opts)
  for batch,hq,hkv,nq,nk in [(1,2,2,17,17),(1,4,2,65,65),(2,4,2,129,97),(1,2,2,257,257)]:
   # Last-stride one but head and sequence axes match model permutation.
   q=torch.randn(batch,nq,hq,128,device='cuda',dtype=torch.bfloat16).permute(0,2,1,3)
   k=torch.randn(batch,nk,hkv,128,device='cuda',dtype=torch.bfloat16).permute(0,2,1,3)
   v=torch.randn_like(k); output=torch.empty_like(q)
   lens=torch.full((batch,),nk,device='cuda',dtype=torch.int32)
   empty=torch.empty((1,1,1,128),device='cuda',dtype=torch.bfloat16)
   scale=128**-0.5
   if args.mode=='aot':
    from ninetoothed.aot import _ArgumentTensor
    # The wrapper takes NineToothedTensor even for unused constexpr formals.
    scale_arg = _ArgumentTensor.from_scalar(scale, ctypes.c_float)
    kernel(q,k,v,lens,empty,float(causal),scale_arg,output,0.0,float(fa.CausalVariant.LOWER_RIGHT))
   else:
    kernel(q,k,v,lens,empty,bool(causal),scale,output,False,int(fa.CausalVariant.LOWER_RIGHT))
   torch.cuda.synchronize()
   kk=k.repeat_interleave(hq//hkv,1); vv=v.repeat_interleave(hq//hkv,1)
   scores=torch.matmul(q.float(),kk.float().transpose(-2,-1))*scale
   if causal:
    mask=torch.arange(nq,device='cuda')[:,None]+nk-nq>=torch.arange(nk,device='cuda')[None,:]
    scores=scores.masked_fill(~mask,float('-inf'))
   expected=torch.matmul(torch.softmax(scores,dim=-1).to(torch.bfloat16).float(),vv.float()).to(torch.bfloat16)
   # LOWER_RIGHT with nq > nk has fully masked leading queries; avoid undefined oracle NaNs.
   start=max(nq-nk,0) if causal else 0
   torch.testing.assert_close(output[:,:,start:],expected[:,:,start:],atol=0.04,rtol=0.04)
   report['cases'].append({'causal':causal,'shape':[batch,hq,hkv,nq,nk,128],'max_abs_error':(output[:,:,start:].float()-expected[:,:,start:].float()).abs().max().item()})
 report['passed']=True
except Exception:
 report['error']=traceback.format_exc(); raise
finally:
 report['generated_files']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in args.output_dir.iterdir() if p.is_file()}
 (args.output_dir/'result.json').write_text(json.dumps(report,indent=2))
 print(json.dumps(report,indent=2),flush=True)
