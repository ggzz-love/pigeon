"""Isolated device validation of the NineToothed HIP AOT backend candidate."""
import difflib, hashlib, json, os, pathlib, subprocess, sys, tempfile, time, zipfile

afs=pathlib.Path(os.environ['IFAB_AFS_HOME'])
here=pathlib.Path(__file__).resolve().parent
run=pathlib.Path(os.environ['H3_NINE_MHA_VALIDATION_RUN'])
assert run.parent==afs/'h3/runs' and run.name.startswith('nine-mha-e2e-')
run.mkdir(parents=True,exist_ok=False)
deps=pathlib.Path(tempfile.mkdtemp(prefix='h3-nine-mha-'))
wheels={
 'ninetoothed-0.25.0-py3-none-any.whl':'c6628e512c458801d6387ee5c658ab9fbe1cf3a906739337cb85fbe567cdfefb',
 'numpy-1.26.4-cp311-cp311-manylinux_2_17_x86_64.manylinux2014_x86_64.whl':'666dbfb6ec68962c033a450943ded891bed2d54e6755e35e5835d63f4f6931d5',
}
for name,expected in wheels.items():
 raw=(afs/name).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==expected,name
 with zipfile.ZipFile(afs/name) as z:
  for item in z.infolist():
   parts=pathlib.PurePosixPath(item.filename).parts
   assert '..' not in parts and not item.filename.startswith('/')
   target=deps.joinpath(*parts)
   if item.is_dir(): target.mkdir(parents=True,exist_ok=True)
   else:
    target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(z.read(item))
original=deps/'ninetoothed/aot.py'
before=original.read_text()
assert hashlib.sha256(original.read_bytes()).hexdigest()==os.environ['H3_NINE_ORIGINAL_AOT_SHA256']
after=(here/'aot.py').read_text()
original.write_text(after)
(run/'ninetoothed-hcu-aot.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='ninetoothed/aot.py.original',tofile='ninetoothed/aot.py')))
generation=deps/'ninetoothed/generation.py'
text=generation.read_text()
needle='CACHE_DIR = pathlib.Path.home() / ".ninetoothed"'
assert text.count(needle)==1
generation.write_text(text.replace(needle,'CACHE_DIR = pathlib.Path(__import__("os").environ["NINETOOTHED_CACHE_DIR"])'))
(deps/'h3_private_cache.py').write_bytes((here/'h3_private_cache.py').read_bytes())
for name in ['sitecustomize.py','h3_backend_compat.py']:
 (deps/name).write_bytes((here/name).read_bytes())
env=os.environ.copy()
env['H3_NINE_GEP_COMPAT']='1'
env['H3_NINE_MHA_CONTIGUOUS_LAST']='1'
env['H3_BACKEND_AUDIT']=str(run/'backend-audit')
env.update(PYTHONPATH=str(deps),PYTHONNOUSERSITE='1',
 TRITON_CACHE_MANAGER='h3_private_cache:PrivateProcessCache',
 TRITON_CACHE_DIR=str(deps/'triton-cache'),NINETOOTHED_CACHE_DIR=str(deps/'nine-cache'))
report={'scope':'upstream Nine MHA HIP backend validation; no model integration claim',
 'started':time.time(),'passed':False,'wheel_sha256':wheels,
 'original_aot_sha256':hashlib.sha256(before.encode()).hexdigest(),
 'candidate_aot_sha256':hashlib.sha256(after.encode()).hexdigest(),'modes':{}}
print('NINE_HIP_AOT_RUN='+str(run),flush=True)
for mode in ['aot','jit']:
 output=deps/mode
 with (run/(mode+'.log')).open('w') as log:
  p=subprocess.Popen([sys.executable,'-u',str(here/'nine_swiglu_selftest.py'),'--mode',mode,'--output-dir',str(output)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1)
  for line in p.stdout:
   print(line,end='',flush=True); log.write(line); log.flush()
  code=p.wait()
 result=output/'result.json'
 report['modes'][mode]={'exit_code':code,'result':json.loads(result.read_text()) if result.is_file() else None}
 for artifact in output.rglob('*'):
  if artifact.is_file():
   destination=run/mode/artifact.relative_to(output)
   destination.parent.mkdir(parents=True,exist_ok=True); destination.write_bytes(artifact.read_bytes())
 report['ended']=time.time()
 (run/'result.json').write_text(json.dumps(report,indent=2))
 if code: break
report['passed']=len(report['modes'])==2 and all(v['exit_code']==0 and v['result'] and v['result']['passed'] for v in report['modes'].values())
(run/'result.json').write_text(json.dumps(report,indent=2))
(run/'flash_attention.py').write_bytes((here/'flash_attention.py').read_bytes())
(run/'nine_mha_selftest.py').write_bytes((here/'nine_swiglu_selftest.py').read_bytes())
print(json.dumps(report,indent=2),flush=True)
raise SystemExit(0 if report['passed'] else 1)
