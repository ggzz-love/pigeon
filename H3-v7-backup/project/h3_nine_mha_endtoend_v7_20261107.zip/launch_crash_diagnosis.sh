#!/usr/bin/env bash
source /opt/dtk/env.sh
set -euo pipefail
source "$IFAB_AFS_HOME/h3/envs/py311-20261105-v1/bin/activate"
export PYTHONNOUSERSITE=1
export FA_SO_PATH="$VIRTUAL_ENV/lib/python3.11/site-packages/flash_attn_2_cuda.cpython-311-x86_64-linux-gnu.so"
export INFINI_ROOT="$IFAB_AFS_HOME/h3/runs/framework-live-20261106-185415/install"
export LD_LIBRARY_PATH="$INFINI_ROOT/lib:/opt/dtk/lib:/opt/dtk/cuda/cuda/lib64:/usr/local/lib/python3.11/site-packages/torch/lib:/opt/hyhal/lib:${LD_LIBRARY_PATH:-}"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export H3_BASELINE_HELPERS="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export H3_RUNTIME_CACHE_POINTER="$IFAB_AFS_HOME/h3/cache/python-runtime-gcc-pair-latest.json"
export H3_NATIVE_TRACE_ONLY=1
export H3_REFERENCE_FL2VA_VIDEO="$IFAB_AFS_HOME/h3/runs/baseline-preflight-20261106-234201/comparison/reference_fl2va.mp4"
cc -shared -fPIC -O2 -o "$H3_BASELINE_HELPERS/h3_crash_trace.so" "$H3_BASELINE_HELPERS/h3_crash_trace.c" -ldl
exec python -u "$H3_BASELINE_HELPERS/launch_crash_diagnosis.py"
