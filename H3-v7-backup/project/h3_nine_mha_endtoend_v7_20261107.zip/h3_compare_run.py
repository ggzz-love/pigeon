"""Run the unchanged official FL2VA comparison and retain real evidence.

The official script's successful exit is not an organizer acceptance decision.
"""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback


COMPARE_SHA = 'e143c28e4b3acb885662e0aa238aa00ca17cbcc82077f465f2ce57d0f1225590'
IMAGE_SHA = '1e71abf29876f248088a11211a350ed3d26a0c68aa34f6e45738771eb2d45a22'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def probe_video(path):
    import av
    with av.open(str(path)) as container:
        stream = container.streams.video[0]
        info = dict(width=stream.width, height=stream.height,
                    fps=str(stream.average_rate), codec=stream.codec_context.name,
                    audio=[dict(codec=s.codec_context.name,
                                sample_rate=s.codec_context.sample_rate)
                           for s in container.streams.audio])
        info['decoded_frames'] = sum(1 for _ in container.decode(video=0))
    return info


def main():
    afs = Path(os.environ['IFAB_AFS_HOME'])
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--framework-prefix', type=Path, required=True)
    parser.add_argument('--source-root', type=Path,
                        default=afs/'h3/runs/cpu-py-src-cc180812')
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--model-path', type=Path,
                        default=Path('/public/home/aclsylqidf/shared/MiniMax-H3'))
    parser.add_argument('--first-frame', type=Path, default=afs/'h3/\u8f93\u5165\u56fe\u7247.jpg')
    parser.add_argument('--reference-fl2va-video', type=Path,
                        help='Existing official reference, for correctness only; no generated-reference speedup is claimed')
    parser.add_argument('--native-crash-trace', type=Path,
                        help='Optional host-side diagnostic library for the model subprocess')
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = dict(scope='official FL2VA comparison; organizer acceptance not inferred',
                  completed=False, started=time.time(), argv=sys.argv,
                  fixed_generation=dict(prompt='A dog falls asleep', seed=42,
                                        steps=50, frames=124, fps=24))
    code = 1
    try:
        source = args.source_root.resolve()
        compare = source/'InfiniLM/examples/minimax_h3_compare.py'
        assert digest(compare) == COMPARE_SHA, 'Official comparison script differs'
        assert digest(args.first_frame) == IMAGE_SHA, 'First-frame image differs'
        assert args.model_path.is_dir(), 'Shared model path is unavailable'
        assert (args.framework_prefix/'lib').is_dir(), 'Framework libraries absent'
        env = os.environ.copy()
        env['PYTHONNOUSERSITE'] = '1'
        env['PYTHONUNBUFFERED'] = '1'
        env['HF_HUB_OFFLINE'] = '1'
        env['TRANSFORMERS_OFFLINE'] = '1'
        env['INFINI_ROOT'] = str(args.framework_prefix.resolve())
        paths = [source/repo/'python' for repo in ['InfiniCore', 'InfiniLM']]
        xxhash = afs/'h3/deps/xxhash-3.6.0'
        if xxhash.is_dir():
            paths.insert(0, xxhash)
        runtime = env.get('H3_PYTHON_RUNTIME')
        if runtime:
            paths.insert(0, Path(runtime))
        env['PYTHONPATH'] = os.pathsep.join(map(str, paths))
        env['LD_LIBRARY_PATH'] = str(args.framework_prefix.resolve()/'lib') + ':' + env.get('LD_LIBRARY_PATH', '')
        # Use a child with the exact launch environment for dependency/device checks.
        preflight = r'''
import importlib.metadata,json,torch,triton,infinicore,infinilm
assert torch.cuda.is_available(), 'No accelerator visible'
assert torch.cuda.device_count() >= 8, 'This launch requires eight assigned cards'
assert torch.version.hip, 'Expected the vendor HIP build'
print(json.dumps({'torch':torch.__version__,'triton':triton.__version__,
 'hip':torch.version.hip,'devices':[str(torch.cuda.get_device_properties(i)) for i in range(8)],
 'infinicore':infinicore.__file__,'infinilm':infinilm.__file__,
 'packages':{p:importlib.metadata.version(p) for p in ['torch','triton','numpy','diffusers','transformers']}}))
'''
        if args.native_crash_trace:
            preflight = 'import torch; assert torch.version.hip and torch.cuda.device_count() >= 8; print("DIAGNOSTIC_DEVICE_CHECK_OK", torch.__version__)'
        pre = subprocess.run([sys.executable, '-c', preflight], env=env,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, encoding='utf-8', errors='replace', timeout=180)
        (output/'preflight.log').write_text(pre.stdout, encoding='utf-8')
        assert pre.returncode == 0, 'Preflight failed; see preflight.log'
        command = [sys.executable, str(compare), '--tasks=fl2va',
                   f'--model-path={args.model_path}', f'--first-frame={args.first_frame}',
                   f'--output-dir={output}', '--legacy-gpus=0,1,2,3,4,5,6,7',
                   '--legacy-memory-fraction=0.4', '--infinilm-gpus=0,1,2,3,4,5,6,7']
        if args.reference_fl2va_video:
            reference=args.reference_fl2va_video.resolve()
            assert reference.is_file(), 'Provided official reference is absent'
            metadata=probe_video(reference)
            assert metadata['decoded_frames']==124 and metadata['fps'] in ['24','24/1'],metadata
            report['provided_reference']=dict(path=str(reference),sha256=digest(reference),**metadata)
            report['performance_scope']='Correctness against provided reference; no reference generation speedup claimed'
            command.append('--reference-fl2va-video='+str(reference))
        if args.native_crash_trace:
            trace = args.native_crash_trace.resolve()
            assert trace.is_file(), trace
            if env.get('H3_NATIVE_TRACE_ONLY') == '1':
                env.pop('PYTHONFAULTHANDLER', None)
            else:
                env['PYTHONFAULTHANDLER'] = '1'
            env['LD_PRELOAD'] = ' '.join(filter(None, [str(trace), env.get('LD_PRELOAD')]))
            report['native_crash_trace_sha256'] = digest(trace)
        if env.get('H3_NINE_MHA_ARTIFACTS'):
            startup=Path(env['H3_NINE_MHA_STARTUP'])
            assert (startup/'sitecustomize.py').is_file()
            env['PYTHONPATH']=str(startup)+os.pathsep+env['PYTHONPATH']
            report['nine_mha_validation_required']=True
        report.update(command=command, comparison_sha256=digest(compare),
                      first_frame_sha256=digest(args.first_frame),
                      framework_prefix=env['INFINI_ROOT'])
        (output/'launch.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        with (output/'comparison.log').open('w', encoding='utf-8') as log:
            child = subprocess.Popen(command, cwd=source/'InfiniLM', env=env,
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     text=True, encoding='utf-8', errors='replace', bufsize=1)
            for line in child.stdout:
                print(line, end='', flush=True)
                log.write(line)
                log.flush()
            code = child.wait()
        report['comparison_exit_code'] = code
        report['videos'] = {}
        for name in ['reference_fl2va.mp4', 'infinilm_fl2va.mp4']:
            video = (args.reference_fl2va_video.resolve()
                     if name=='reference_fl2va.mp4' and args.reference_fl2va_video else output/name)
            if video.is_file():
                report['videos'][name] = dict(sha256=digest(video), **probe_video(video))
        report['completed'] = code == 0 and len(report['videos']) == 2
        if report['completed']:
            for info in report['videos'].values():
                assert info['decoded_frames'] == 124, 'Unexpected frame count'
                assert info['fps'] in ['24', '24/1'], 'Unexpected frame rate'
        else:
            code = code or 1
    except Exception:
        report['error'] = traceback.format_exc()
        print(report['error'], flush=True)
        report['completed'] = False
        code = 1
    finally:
        report['ended'] = time.time()
        (output/'evidence.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    return code


if __name__ == '__main__':
    raise SystemExit(main())
