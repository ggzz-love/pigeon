"""Nine target adapter for GEP flags unsupported by the vendor LLVM reader."""
import functools, hashlib, inspect, json, os, pathlib, re
def normalize_gep_flags(source):
    # Remove only newer optional no-wrap flags on getelementptr instructions.
    return re.sub(r'\bgetelementptr\s+(?:(?:inbounds|nuw|nusw)\s+)+',
                  lambda m:'getelementptr '+('inbounds ' if 'inbounds' in m.group(0).split() else ''),source)
def install():
    import triton.backends.amd.compiler as backend
    cls=backend.HIPBackend
    method=cls.make_amdgcn
    audit=pathlib.Path(os.environ['H3_BACKEND_AUDIT'])
    audit.mkdir(exist_ok=True,parents=True)
    original=inspect.getsource(backend)
    (audit/'vendor-compiler-source.py').write_text(original)
    @functools.wraps(method)
    def compatible(src,metadata,options):
        assert isinstance(src,str)
        fixed=normalize_gep_flags(src)
        sha=hashlib.sha256(src.encode()).hexdigest()
        info={'source_sha256':sha,'normalized_sha256':hashlib.sha256(fixed.encode()).hexdigest(),
              'changed':src!=fixed,'scope':'GEP optional no-wrap flags only',
              'vendor_backend_sha256':hashlib.sha256(original.encode()).hexdigest()}
        (audit/(sha+'.json')).write_text(json.dumps(info,indent=2))
        (audit/(sha+'.llir-excerpt.txt')).write_text(src[:32000])
        print('NINE_GEP_COMPAT '+json.dumps(info),flush=True)
        return method(fixed,metadata,options)
    cls.make_amdgcn=staticmethod(compatible)
    print('NINE_BACKEND_COMPAT_INSTALLED',hashlib.sha256(original.encode()).hexdigest(),flush=True)
