"""Validate Nine MHA through the actual InfiniCore dispatch table."""
import ctypes, json, os, pathlib, subprocess, sys
import torch
import infinicore as ic
from infinicore.ops.mha import mha

folder=pathlib.Path(sys.argv[1])
patch=pathlib.Path(sys.argv[2])
prefix=pathlib.Path(os.environ['INFINI_ROOT'])
source=patch/'mha_nine_plugin.cpp'
plugin=folder/'h3_nine_mha_plugin.so'
subprocess.run(['c++','-std=c++20','-O2','-fPIC','-shared','-Wl,-z,defs',
 '-I'+str(prefix/'include'),str(source),'-L'+str(prefix/'lib'),
 '-Wl,-rpath,'+str(prefix/'lib'),'-linfinicore_cpp_api','-ldl','-o',str(plugin)],check=True)
kernels=[ctypes.CDLL(str(folder/f'h3_nine_mha_bf16_c{c}.so'),mode=ctypes.RTLD_GLOBAL) for c in (0,1)]
bridge=ctypes.CDLL(str(plugin),mode=ctypes.RTLD_GLOBAL)
bridge.h3_nine_mha_launch_count.restype=ctypes.c_uint64
present=bridge.h3_mha_has_native_plan()
print('HYGON_MHA_NATIVE_PLAN_BEFORE='+str(present),flush=True)
assert present==0 and bridge.h3_register_nine_mha()==0 and bridge.h3_mha_has_native_plan()==1
result=[]
device_count=torch.cuda.device_count()
assert device_count == 8, f'expected 8 visible cards, got {device_count}'
for device_id in range(device_count):
 ic.set_device(ic.device('cuda', device_id))
 torch.cuda.set_device(device_id)
 torch.manual_seed(42)
 first=len(result)
 for dim in [72,128]:
  for causal in [False,True]:
   for batch,heads,kvheads,seq in ([(1,4,2,17),(1,8,1,65),(2,4,2,129)] if device_id == 0 else [(1,4,2,17)]):
    q=torch.randn(batch,seq,heads,dim,device='cuda',dtype=torch.bfloat16)
    k=torch.randn(batch,seq,kvheads,dim,device='cuda',dtype=torch.bfloat16)
    v=torch.randn_like(k); out=torch.empty_like(q)
    torch.cuda.synchronize()
    scale=dim**-0.5
    mha(ic.from_torch(q),ic.from_torch(k),ic.from_torch(v),scale=scale,is_causal=causal,out=ic.from_torch(out))
    ic.sync_device()
    torch.cuda.synchronize()
    kk=k.float().permute(0,2,1,3).repeat_interleave(heads//kvheads,1)
    vv=v.float().permute(0,2,1,3).repeat_interleave(heads//kvheads,1)
    scores=q.float().permute(0,2,1,3)@kk.transpose(-2,-1)*scale
    if causal: scores=scores.masked_fill(torch.ones(seq,seq,dtype=torch.bool,device='cuda').triu(1),float('-inf'))
    expected=(scores.softmax(-1)@vv).permute(0,2,1,3).to(torch.bfloat16)
    torch.testing.assert_close(out,expected,atol=0.04,rtol=0.04)
    result.append(dict(device=device_id,dim=dim,causal=causal,seq=seq,batch=batch,heads=heads,kvheads=kvheads,
                       max_abs_error=(out.float()-expected.float()).abs().max().item()))
 print('NINE_MHA_DEVICE_PASS', device_id, len(result)-first, flush=True)
count=bridge.h3_nine_mha_launch_count()
assert count==len(result)
report=dict(passed=True,missing_dispatch_confirmed=True,cases=result,successful_nine_launches=count,devices=device_count)
(folder/'native-dispatch-result.json').write_text(json.dumps(report,indent=2))
print('HYGON_MHA_NATIVE_NINE_DISPATCH_PASS '+json.dumps(report),flush=True)
