"""Run the official FL2VA generator with verified Nine MHA device code."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verified_kernels(validation, artifacts):
    summary = json.loads((validation/'result.json').read_text())
    assert summary['passed'] and summary['modes']['aot']['result']['passed']
    assert summary['modes']['jit']['result']['passed']
    dispatch = json.loads((validation/'native-dispatch-result.json').read_text())
    assert dispatch['passed'] and dispatch['devices'] == 8
    assert dispatch['successful_nine_launches'] == 40
    binaries = {}
    for causal in (0, 1):
        name = f'h3_nine_mha_bf16_c{causal}.so'
        path = validation/'aot'/name
        digest = summary['modes']['aot']['result']['generated_files'][name]
        assert sha256(path) == digest, name
        shutil.copyfile(path, artifacts/name)
        binaries[name] = digest
    return binaries


def media_info(output):
    import av

    with av.open(str(output)) as media:
        video = media.streams.video[0]
        audio = media.streams.audio[0]
        return {'width': video.width, 'height': video.height, 'fps': float(video.average_rate),
                'video_codec': video.codec_context.name, 'audio_codec': audio.codec_context.name,
                'audio_channels': audio.channels, 'audio_sample_rate': audio.sample_rate,
                'decoded_frames': sum(1 for _ in media.decode(video=0)), 'sha256': sha256(output)}


def run(afs, source, run_dir, helpers, runtime_env, cli):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verified-nine-run', type=Path,
                        default=afs/'h3/runs/nine-mha-e2e-20261107-105820')
    parser.add_argument('--model-path', type=Path, default=Path('/public/home/aclsylqidf/shared/MiniMax-H3'))
    parser.add_argument('--first-frame', type=Path, default=afs/'h3/\u8f93\u5165\u56fe\u7247.jpg')
    parser.add_argument('--output', type=Path, default=run_dir/'infinilm_fl2va.mp4')
    parser.add_argument('--text', default='A dog falls asleep')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--steps', type=int, default=50)
    parser.add_argument('--num-frames', type=int, default=124)
    args = parser.parse_args(cli)

    entry = source/'InfiniLM/examples/minimax_h3.py'
    entry_digest = sha256(entry)
    assert entry_digest == 'ca54a18a73a7d760d644ca4eb2c3b20678f88dfdbcfa26a62dcd3de617b31af4'
    artifacts = helpers/'verified-kernels'
    artifacts.mkdir()
    binaries = verified_kernels(args.verified_nine_run, artifacts)
    prefix = Path(os.environ['INFINI_ROOT'])
    plugin = artifacts/'h3_nine_mha_plugin.so'
    subprocess.run(['c++', '-std=c++20', '-O2', '-fPIC', '-shared', '-Wl,-z,defs',
                    '-I'+str(prefix/'include'), str(helpers/'mha_nine_plugin.cpp'),
                    '-L'+str(prefix/'lib'), '-Wl,-rpath,'+str(prefix/'lib'),
                    '-linfinicore_cpp_api', '-ldl', '-o', str(plugin)], check=True)
    runtime_env['H3_NINE_MHA_ARTIFACTS'] = str(artifacts)
    runtime_env['PYTHONPATH'] = os.pathsep.join([str(helpers/'mha_startup'), runtime_env['PYTHONPATH']])
    args.output = args.output.resolve()
    assert not args.output.exists(), f'Output exists: {args.output}'
    command = [sys.executable, '-u', str(entry), 'fl2va', f'--model-path={args.model_path}',
               f'--first-frame={args.first_frame}', f'--output={args.output}', f'--text={args.text}',
               f'--seed={args.seed}', f'--steps={args.steps}', f'--num-frames={args.num_frames}',
               '--gpus=0,1,2,3,4,5,6,7']
    evidence = {'entry_sha256': entry_digest, 'first_frame_sha256': sha256(args.first_frame),
                'kernel_sha256': binaries, 'plugin_sha256': sha256(plugin),
                'command': command, 'video': None, 'scope': 'FL2VA generation and media verification'}
    devices = set()
    with (run_dir/'generation.log').open('w', encoding='utf-8') as log:
        process = subprocess.Popen(command, env=runtime_env, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace')
        for line in process.stdout:
            print(line, end='', flush=True)
            log.write(line)
            if line.startswith('H3_NINE_MHA_LAUNCH '):
                devices.add(int(line.split(' device=', 1)[1].split(' ', 1)[0]))
        code = process.wait()
    evidence.update(generation_exit_code=code, observed_nine_devices=sorted(devices))
    if code == 0 and args.output.is_file():
        evidence['video'] = media_info(args.output)
    (run_dir/'evidence.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')
    assert code == 0, f'FL2VA generation exited {code}'
    assert devices == set(range(8)), f'Missing Nine MHA dispatch: {devices}'
    assert evidence['video'] is not None and evidence['video']['decoded_frames'] == args.num_frames
    print('H3_DIRECT_GENERATION_VERIFIED ' + json.dumps(evidence), flush=True)
