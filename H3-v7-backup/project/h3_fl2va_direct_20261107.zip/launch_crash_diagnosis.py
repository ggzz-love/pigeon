import hashlib,io,json,os,pathlib,subprocess,sys,tarfile,tempfile,time,threading

afs=pathlib.Path(os.environ['IFAB_AFS_HOME'])
source=afs/'h3/runs/cpu-py-src-cc180812'
run=afs/'h3/runs'/('nine-fl2va-direct-'+time.strftime('%Y%m%d-%H%M%S'))
run.mkdir(parents=True,exist_ok=False)
cache=json.loads(pathlib.Path(os.environ['H3_RUNTIME_CACHE_POINTER']).read_text())
assert cache['complete'] is True
raw=pathlib.Path(cache['archive']).read_bytes()
assert hashlib.sha256(raw).hexdigest()==cache['archive_sha256']
manifest=json.loads(pathlib.Path(cache['manifest']).read_text())
local_runtime=pathlib.Path(tempfile.mkdtemp(prefix='h3-python-runtime-'))
local_runtime.mkdir(exist_ok=True)
count=0
print('RUNTIME_CACHE_EXTRACT_START',cache['files_written'],cache['packages'],flush=True)
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
 for member in tf:
  parts=pathlib.PurePosixPath(member.name).parts
  assert '..' not in parts and not member.name.startswith('/') and member.isfile()
  data=tf.extractfile(member).read()
  expected=manifest['files'][member.name]
  assert len(data)==expected['bytes']
  assert hashlib.sha256(data).hexdigest()==expected['sha256'],member.name
  target=local_runtime.joinpath(*parts); target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(data); count+=1
  if count%500==0: print('RUNTIME_CACHE_EXTRACT',count,flush=True)
assert count==cache['files_written']
print('RUNTIME_CACHE_VERIFIED',count,local_runtime,flush=True)
env=os.environ.copy()
env['H3_PYTHON_RUNTIME']=str(local_runtime)
env['PYTHONPATH']=os.pathsep.join(str(p) for p in [local_runtime,afs/'h3/deps/xxhash-3.6.0',source/'InfiniCore/python',source/'InfiniLM/python'])

from launch_direct import run as run_generation
print('H3_DIRECT_RUN_DIR=' + str(run), flush=True)
run_generation(afs, source, run, pathlib.Path(os.environ['H3_BASELINE_HELPERS']), env, sys.argv[1:])
